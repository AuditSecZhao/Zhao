<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
 <head>
  <link rel="stylesheet" href="http://st.pimg.net/tucs/style.css" type="text/css" />
<style>
.styleswitch {
  text-align: right;
}
</style>


<script type="text/javascript" src="http://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="http://st.pimg.net/tucs/js/jquery.cookie.js"></script>
<script type="text/javascript" src="http://st.pimg.net/tucs/js/sh_main.min.js"></script>
<script type="text/javascript" src="http://st.pimg.net/tucs/js/sh_perl.min.js"></script>
<script type="text/javascript" src="http://st.pimg.net/tucs/js/jquery.styleswitch.js"></script>

<link rel="stylesheet" href="http://st.pimg.net/tucs/print.css" type="text/css" media="print" />
  <link rel="alternate" type="application/rss+xml" title="RSS 1.0" href="http://search.cpan.org/uploads.rdf" />
  <link rel="search" href="http://st.pimg.net/tucs/opensearch.xml" type="application/opensearchdescription+xml" title="SearchCPAN" />
  <title>IO::Tty - search.cpan.org</title>
 <script type="text/javascript">
    var _gaq = _gaq || [];
    _gaq.push(['_setAccount', 'UA-3528438-1']);
    _gaq.push(["_setCustomVar",2,"Distribution","IO-Tty",3]);
    _gaq.push(["_setCustomVar",5,"Release","IO-Tty-1.10",3]);
    _gaq.push(["_setCustomVar",3,"Module","IO::Tty",3]);
    _gaq.push(["_setCustomVar",1,"Author","TODDR",3]);
    _gaq.push(['_trackPageview']);
  </script>
 </head>
 <body id="cpansearch">
<center><div class="logo"><a href="/"><img src="http://st.pimg.net/tucs/img/cpan_banner.png" alt="CPAN"></a></div></center>
<div class="menubar">
 <a href="/">Home</a>
&middot; <a href="/author/">Authors</a>
&middot; <a href="/recent">Recent</a>
&middot; <a href="http://log.perl.org/cpansearch/">News</a>
&middot; <a href="/mirror">Mirrors</a>
&middot; <a href="/faq.html">FAQ</a>
&middot; <a href="/feedback">Feedback</a>
</div>
<form method="get" action="/search" name="f" class="searchbox">
<input type="text" name="query" value="" size="35">
<br>in <select name="mode">
 <option value="all">All</option>
 <option value="module" >Modules</option>
 <option value="dist" >Distributions</option>
 <option value="author" >Authors</option>
</select>&nbsp;<input type="submit" value="CPAN Search">
</form>


 <a name="_top"></a>
  <div class=path>
<div id=permalink class="noprint"><a href="/perldoc?IO%3A%3ATty">permalink</a></div>
  <a href="/~toddr/">Todd Rinaldo</a> &gt;
  <a href="/~toddr/IO-Tty-1.10/">IO-Tty-1.10</a> &gt;
  IO::Tty
 </div>

<div class="noprint" style="float:right;align:left;width:19ex">
<a href="http://hexten.net/cpan-faces/"><img src="http://www.gravatar.com/avatar/593351ab4ba45a73fb5de512d89432d2?r=g&s=80&d=http%3A%2F%2Fst.pimg.net%2Ftucs%2Fimg%2Fwho.png" width=80 height=80 
style="float:right"
/></a>
<br style="clear:both"/>
<p style="text-align:right">Download:<br/> <a href="/CPAN/authors/id/T/TO/TODDR/IO-Tty-1.10.tar.gz">IO-Tty-1.10.tar.gz</a></p>
<p style="text-align:right"><a href="http://deps.cpantesters.org/?module=IO%3A%3ATty;perl=latest">Dependencies</a></p>
<p style="text-align:right"><a href="http://www.annocpan.org/~TODDR/IO-Tty-1.10/Tty.pm">Annotate this POD
</a></p>
<div class=box style='width:150px; float: right'>
<h1 class=t5>Related Modules</h1>
<div style="margin:2px">
<a href="/perldoc?Class%3A%3ADBI">Class::DBI</a><br>
<a href="/perldoc?Net%3A%3ATelnet">Net::Telnet</a><br>
<a href="/perldoc?Rose%3A%3ADB">Rose::DB</a><br>
<a href="/perldoc?Class%3A%3ADBI%3A%3Amysql">Class::DBI::mysql</a><br>
<a href="/perldoc?IO%3A%3AStty">IO::Stty</a><br>
<a href="/perldoc?Rose%3A%3ADB%3A%3AObject">Rose::DB::Object</a><br>
<a href="/perldoc?Net%3A%3ASCP">Net::SCP</a><br>
<a href="/perldoc?IO%3A%3AFile">IO::File</a><br>
<a href="/perldoc?IPC%3A%3ARun">IPC::Run</a><br>
<a href="/perldoc?Digest%3A%3AMD5">Digest::MD5</a><br>
<small>
<a href="http://perlmonks.org/?node=cpan+module+search&pivot=1&module=IO%3A%3ATty">more...</a><br>
By <a href="http://perlmonks.org/">perlmonks.org</a></small>
</div>
</div>

<div style="float:right">
<div class=box style='width:150px'>
<h1 class=t5>CPAN RT</h1>
<div style="margin:2px">
<table style="margin-left:auto;margin-right:auto">
<tr><td>New&nbsp;</td><td style="text-align:right"> 3</td></tr>
<tr><td>Open&nbsp;</td><td style="text-align:right"> 5</td></tr>
<tr><td>Stalled&nbsp;</td><td style="text-align:right"> 1</td></tr>
</table>
<a href="https://rt.cpan.org/Public/Dist/Display.html?Name=IO-Tty">View/Report Bugs</a><br/>
</div>
</div>

</div>
</div>
  Module Version:  1.10 &nbsp;
<span class="noprint">
  <a href="/src/TODDR/IO-Tty-1.10/Tty.pm">Source</a> &nbsp;
</span>
<a name="___top"></a>
<div class=pod>
<div class=toc>
<div class='indexgroup'>
<ul   class='indexList indexList1'>
  <li class='indexItem indexItem1'><a href='#NAME'>NAME</a>
  <li class='indexItem indexItem1'><a href='#VERSION'>VERSION</a>
  <li class='indexItem indexItem1'><a href='#SYNOPSIS'>SYNOPSIS</a>
  <li class='indexItem indexItem1'><a href='#DESCRIPTION'>DESCRIPTION</a>
  <li class='indexItem indexItem1'><a href='#VERIFIED_SYSTEMS,_KNOWN_ISSUES'>VERIFIED SYSTEMS, KNOWN ISSUES</a>
  <li class='indexItem indexItem1'><a href='#SEE_ALSO'>SEE ALSO</a>
  <li class='indexItem indexItem1'><a href='#MAILING_LISTS'>MAILING LISTS</a>
  <li class='indexItem indexItem1'><a href='#AUTHORS'>AUTHORS</a>
  <li class='indexItem indexItem1'><a href='#COPYRIGHT'>COPYRIGHT</a>
  <li class='indexItem indexItem1'><a href='#DISCLAIMER'>DISCLAIMER</a>
</ul>
</div>
</div>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="NAME"
>NAME <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<p>IO::Tty - Low-level allocate a pseudo-Tty,
import constants.</p>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="VERSION"
>VERSION <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<p>1.10</p>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="SYNOPSIS"
>SYNOPSIS <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<pre class="sh_perl">    use IO::Tty qw(TIOCNOTTY);
    ...
    # use only to import constants, see IO::Pty to create ptys.</pre>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="DESCRIPTION"
>DESCRIPTION <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<p><code>IO::Tty</code> is used internally by <code>IO::Pty</code> to create a pseudo-tty. You wouldn&#39;t want to use it directly except to import constants, use <code>IO::Pty</code>. For a list of importable constants, see <a href="/~toddr/IO-Tty-1.10/Makefile.PL" class="podlinkpod"
>IO::Tty::Constant</a>.</p>

<p>Windows is now supported, but ONLY under the Cygwin environment, see <a href="http://sources.redhat.com/cygwin/" class="podlinkurl"
>http://sources.redhat.com/cygwin/</a>.</p>

<p>Please note that pty creation is very system-dependend. From my experience, any modern POSIX system should be fine. Find below a list of systems that <code>IO::Tty</code> should work on. A more detailed table (which is slowly getting out-of-date) is available from the project pages document manager at SourceForge <a href="http://sourceforge.net/projects/expectperl/" class="podlinkurl"
>http://sourceforge.net/projects/expectperl/</a>.</p>

<p>If you have problems on your system and your system is listed in the &#34;verified&#34; list, you probably have some non-standard setup, e.g. you compiled your Linux-kernel yourself and disabled ptys (bummer!). Please ask your friendly sysadmin for help.</p>

<p>If your system is not listed, unpack the latest version of <code>IO::Tty</code>, do a <code>&#39;perl Makefile.PL; make; make test; uname -a&#39;</code> and send me (<em>RGiersig@cpan.org</em>) the results and I&#39;ll see what I can deduce from that. There are chances that it will work right out-of-the-box...</p>

<p>If it&#39;s working on your system, please send me a short note with details (version number, distribution, etc. &#39;uname -a&#39; and &#39;perl -V&#39; is a good start; also, the output from &#34;perl Makefile.PL&#34; contains a lot of interesting info, so please include that as well) so I can get an overview. Thanks!</p>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="VERIFIED_SYSTEMS,_KNOWN_ISSUES"
>VERIFIED SYSTEMS, KNOWN ISSUES <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<p>This is a list of systems that <code>IO::Tty</code> seems to work on (&#39;make test&#39; passes) with comments about &#34;features&#34;:</p>

<ul>
<li>AIX 4.3
<p>Returns EIO instead of EOF when the slave is closed. Benign.</p>
</li>

<li>AIX 5.x</li>

<li>FreeBSD 4.4
<p>EOF on the slave tty is not reported back to the master.</p>
</li>

<li>OpenBSD 2.8
<p>The ioctl TIOCSCTTY sometimes fails. This is also known in Tcl/Expect, see <a href="http://expect.nist.gov/FAQ.html" class="podlinkurl"
>http://expect.nist.gov/FAQ.html</a></p>

<p>EOF on the slave tty is not reported back to the master.</p>
</li>

<li>Darwin 7.9.0</li>

<li>HPUX 10.20 &#38; 11.00
<p>EOF on the slave tty is not reported back to the master.</p>
</li>

<li>IRIX 6.5</li>

<li>Linux 2.2.x &#38; 2.4.x
<p>Returns EIO instead of EOF when the slave is closed. Benign.</p>
</li>

<li>OSF 4.0
<p>EOF on the slave tty is not reported back to the master.</p>
</li>

<li>Solaris 8, 2.7, 2.6
<p>Has the &#34;feature&#34; of returning EOF just once?!</p>

<p>EOF on the slave tty is not reported back to the master.</p>
</li>

<li>Windows NT/2k/XP (under Cygwin)
<p>When you send (print) a too long line (&#62;160 chars) to a non-raw pty, the call just hangs forever and even alarm() cannot get you out. Don&#39;t complain to me...</p>

<p>EOF on the slave tty is not reported back to the master.</p>
</li>

<li>z/OS</li>
</ul>

<p>The following systems have not been verified yet for this version, but a previous version worked on them:</p>

<ul>
<li>SCO Unix</li>

<li>NetBSD
<p>probably the same as the other *BSDs...</p>
</li>
</ul>

<p>If you have additions to these lists, please mail them to &#60;<em>RGiersig@cpan.org</em>&#62;.</p>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="SEE_ALSO"
>SEE ALSO <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<p><a href="/~toddr/IO-Tty-1.10/Pty.pm" class="podlinkpod"
>IO::Pty</a>, <a href="/~toddr/IO-Tty-1.10/Makefile.PL" class="podlinkpod"
>IO::Tty::Constant</a></p>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="MAILING_LISTS"
>MAILING LISTS <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<p>As this module is mainly used by Expect, support for it is available via the two Expect mailing lists, expectperl-announce and expectperl-discuss, at</p>

<pre class="sh_perl">  <a href="http://lists.sourceforge.net/lists/listinfo/expectperl-announce" class="podlinkurl"
>http://lists.sourceforge.net/lists/listinfo/expectperl-announce</a></pre>

<p>and</p>

<pre class="sh_perl">  <a href="http://lists.sourceforge.net/lists/listinfo/expectperl-discuss" class="podlinkurl"
>http://lists.sourceforge.net/lists/listinfo/expectperl-discuss</a></pre>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="AUTHORS"
>AUTHORS <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<p>Originally by Graham Barr &#60;<em>gbarr@pobox.com</em>&#62;, based on the Ptty module by Nick Ing-Simmons &#60;<em>nik@tiuk.ti.com</em>&#62;.</p>

<p>Now maintained and heavily rewritten by Roland Giersig &#60;<em>RGiersig@cpan.org</em>&#62;.</p>

<p>Contains copyrighted stuff from openssh v3.0p1, authored by Tatu Ylonen &#60;ylo@cs.hut.fi&#62;, Markus Friedl and Todd C. Miller &#60;Todd.Miller@courtesan.com&#62;. I also got a lot of inspiry from the pty code in Xemacs.</p>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="COPYRIGHT"
>COPYRIGHT <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<p>Now all code is free software; you can redistribute it and/or modify it under the same terms as Perl itself.</p>

<p>Nevertheless the above AUTHORS retain their copyrights to the various parts and want to receive credit if their source code is used. See the source for details.</p>

<h1><a class='u' href='#___top' title='click to go to top of document'
name="DISCLAIMER"
>DISCLAIMER <img alt='^' src='http://st.pimg.net/tucs/img/up.gif'></a></h1>

<p>THIS SOFTWARE IS PROVIDED ``AS IS&#39;&#39; AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE AUTHORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.</p>

<p>In other words: Use at your own risk. Provided as is. Your mileage may vary. Read the source, Luke!</p>

<p>And finally, just to be sure:</p>

<p>Any Use of This Product, in Any Manner Whatsoever, Will Increase the Amount of Disorder in the Universe. Although No Liability Is Implied Herein, the Consumer Is Warned That This Process Will Ultimately Lead to the Heat Death of the Universe.</p>

</div>
<!-- This should probably be put in the <div class="footer"></div> -->
<script type="text/javascript">
    $(document).ready(function(){
        var startingStyle = $.cookie('css') ? $.cookie('css') : 'http://st.pimg.net/tucs/css/sh_none.min.css';
        $.fn.styleSwitch(startingStyle);
        $("#styleswitch").val(startingStyle);
        sh_highlightDocument();
        $("#styleswitch").bind(($.browser.msie ? "click" : "change"), function() {
            $.fn.styleSwitch($(this).val());
        });
    });
</script>
<div class="styleswitch">
    syntax highlighting:
    <select id="styleswitch">
        <option value="http://st.pimg.net/tucs/css/sh_none.min.css">no syntax highlighting</option>
        <option value="http://st.pimg.net/tucs/css/sh_acid.min.css">acid</option>
        <option value="http://st.pimg.net/tucs/css/sh_berries-dark.min.css">berries-dark</option>
        <option value="http://st.pimg.net/tucs/css/sh_berries-light.min.css">berries-light</option>
        <option value="http://st.pimg.net/tucs/css/sh_bipolar.min.css">bipolar</option>
        <option value="http://st.pimg.net/tucs/css/sh_blacknblue.min.css">blacknblue</option>
        <option value="http://st.pimg.net/tucs/css/sh_bright.min.css">bright</option>
        <option value="http://st.pimg.net/tucs/css/sh_contrast.min.css">contrast</option>
        <option value="http://st.pimg.net/tucs/css/sh_cpan.min.css">cpan</option>
        <option value="http://st.pimg.net/tucs/css/sh_darkblue.min.css">darkblue</option>
        <option value="http://st.pimg.net/tucs/css/sh_darkness.min.css">darkness</option>
        <option value="http://st.pimg.net/tucs/css/sh_desert.min.css">desert</option>
        <option value="http://st.pimg.net/tucs/css/sh_dull.min.css">dull</option>
        <option value="http://st.pimg.net/tucs/css/sh_easter.min.css">easter</option>
        <option value="http://st.pimg.net/tucs/css/sh_emacs.min.css">emacs</option>
        <option value="http://st.pimg.net/tucs/css/sh_golden.min.css">golden</option>
        <option value="http://st.pimg.net/tucs/css/sh_greenlcd.min.css">greenlcd</option>
        <option value="http://st.pimg.net/tucs/css/sh_ide-anjuta.min.css">ide-anjuta</option>
        <option value="http://st.pimg.net/tucs/css/sh_ide-codewarrior.min.css">ide-codewarrior</option>
        <option value="http://st.pimg.net/tucs/css/sh_ide-devcpp.min.css">ide-devcpp</option>
        <option value="http://st.pimg.net/tucs/css/sh_ide-eclipse.min.css">ide-eclipse</option>
        <option value="http://st.pimg.net/tucs/css/sh_ide-kdev.min.css">ide-kdev</option>
        <option value="http://st.pimg.net/tucs/css/sh_ide-msvcpp.min.css">ide-msvcpp</option>
        <option value="http://st.pimg.net/tucs/css/sh_kwrite.min.css">kwrite</option>
        <option value="http://st.pimg.net/tucs/css/sh_matlab.min.css">matlab</option>
        <option value="http://st.pimg.net/tucs/css/sh_navy.min.css">navy</option>
        <option value="http://st.pimg.net/tucs/css/sh_nedit.min.css">nedit</option>
        <option value="http://st.pimg.net/tucs/css/sh_neon.min.css">neon</option>
        <option value="http://st.pimg.net/tucs/css/sh_night.min.css">night</option>
        <option value="http://st.pimg.net/tucs/css/sh_pablo.min.css">pablo</option>
        <option value="http://st.pimg.net/tucs/css/sh_peachpuff.min.css">peachpuff</option>
        <option value="http://st.pimg.net/tucs/css/sh_print.min.css">print</option>
        <option value="http://st.pimg.net/tucs/css/sh_rand01.min.css">rand01</option>
	<option value="http://st.pimg.net/tucs/css/sh_solarized-dark.min.css">solarized-dark</option>
	<option value="http://st.pimg.net/tucs/css/sh_solarized-light.min.css">solarized-light</option>
        <option value="http://st.pimg.net/tucs/css/sh_style.min.css">style</option>
        <option value="http://st.pimg.net/tucs/css/sh_the.min.css">the</option>
        <option value="http://st.pimg.net/tucs/css/sh_typical.min.css">typical</option>
        <option value="http://st.pimg.net/tucs/css/sh_vampire.min.css">vampire</option>
        <option value="http://st.pimg.net/tucs/css/sh_vim-dark.min.css">vim-dark</option>
        <option value="http://st.pimg.net/tucs/css/sh_vim.min.css">vim</option>
        <option value="http://st.pimg.net/tucs/css/sh_whatis.min.css">whatis</option>
        <option value="http://st.pimg.net/tucs/css/sh_whitengrey.min.css">whitengrey</option>
        <option value="http://st.pimg.net/tucs/css/sh_zellner.min.css">zellner</option>
    </select>
</div>



<div class="footer"><div class="cpanstats">89438 Uploads, 27177 Distributions
119769 Modules, 10521 Uploaders
</div>
hosted by <a href="http://www.yellowbot.com">YellowBot</a><br/>
<a href="http://www.yellowbot.com"><img alt="do. tag. write. share." src="http://st.pimg.net/tucs/img/yellowbot_logo.gif"></a>
</div>
<script type="text/javascript">
var gaJsHost = (("https:" == document.location.protocol) ? "https://ssl." : "http://www.");
document.write(unescape("%3Cscript src='" + gaJsHost + "google-analytics.com/ga.js' type='text/javascript'%3E%3C/script%3E"));
</script>
<script type="text/javascript" src="http://ipv4.v6test.develooper.com/js/v1/v6test.js"></script>

<script type="text/javascript">
   // v6.target = '';
   if (!v6.target) { v6.only_once = true }
   v6.site = '7A0D89A6-2B82-11DF-B9DA-F61CBD13F020';
   v6.api_server = 'http://ipv4.v6test.develooper.com';
   try {
     v6.test();
   } catch(err) {}
</script>
<script type="text/javascript">
  $(document).ready(function(){
    $("a[href^=http:]").click(function(){
      var href = $(this).attr('href');
      var m = href.match('\/\/([^\/:]+)');
      _gaq.push(['_trackEvent','External',m[1],'Module']);
    });
    $("a[href^=/CPAN/]").click(function(){
      var href = $(this).attr('href');
      _gaq.push(['_trackEvent','Download',href,'Module']);
    });
  });
</script>
<!-- Fri Mar 29 02:42:44 2013 GMT (0.0734920501708984) @cpansearch1 -->
 </body>
</html>
