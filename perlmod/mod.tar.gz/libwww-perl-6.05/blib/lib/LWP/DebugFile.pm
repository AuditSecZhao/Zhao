package LWP::DebugFile;

# legacy stub

1;
